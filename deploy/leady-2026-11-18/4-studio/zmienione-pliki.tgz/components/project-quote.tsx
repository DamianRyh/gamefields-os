"use client";
import type {QuoteState} from "@/hooks/use-project-quote";
import {PRICE_MODE,concreteBasePrice,constructionPrice,formatPriceRange,matPrintPrice,priceRange,surfaceFinish} from "@/lib/price-range";
import {ACRYLIC_NOTES,EPDM_NOTES,MAT_NOTES,PAINT_NOTES,RUBBER_NOTES,TILE_NOTES,TURF_NOTES} from "@/lib/surface-finish";
import {CONCRETE_BASE_EXCLUDES,CONCRETE_BASE_INCLUDES} from "@/lib/concrete-base";

const money=(value:number)=>new Intl.NumberFormat("pl-PL",{style:"currency",currency:"PLN",maximumFractionDigits:0}).format(value);
const qty=(value:number)=>new Intl.NumberFormat("pl-PL",{maximumFractionDigits:2}).format(value);
/* 2026-11-18: inside the summary it jumps to "Odbierz propozycję na maila", so the project goes with the inquiry;
   elsewhere (no button on screen) it still opens the contact page. */
const contact=<a href="https://www.gamefields.eu/kontakt/" target="_top" onClick={e=>{const t=document.getElementById("gf-inquiry-cta");if(t){e.preventDefault();t.scrollIntoView({behavior:"smooth",block:"center"});t.focus({preventScroll:true})}}}>Odbierz propozycję dla tego projektu ↓</a>;

/* Shop products (plakat, piłka, koszulki) pass their exact price as `label`.
   Courts: construction price only (PRICE_MODE "construction") or the full-project range ("range"). */
export function QuoteBadge({quote,onClick,label}:{quote:QuoteState;onClick:()=>void;label?:string}){
 let text=label,short:string|undefined;
 if(!text){
  if(quote.loading)text="Przeliczam…";
  else if(PRICE_MODE==="construction"){const priced=!!quote.data?.constructionPrices,c=priced?constructionPrice(quote.data):null,surface=priced?(concreteBasePrice(quote.data)??0)+(surfaceFinish(quote.data)?.net??0)+(matPrintPrice(quote.data)??0):0;text=c===null?(surface>0?`${surfaceFinish(quote.data)?.label.startsWith("Mata treningowa")?"Mata":"Nawierzchnia"} ${money(surface)} netto`:"Indywidualna wycena"):surface>0?`Konstrukcja ${money(c)} · Nawierzchnia ${money(surface)} netto`:`Konstrukcja: ${money(c)} netto`;if(c!==null||surface>0)short=`${money((c??0)+surface)} netto`;}
  else{const r=priceRange(quote.data);text=r?formatPriceRange(r):"Indywidualna wycena";}
 }
 return <button className="studio-primary studio-quote-badge" onClick={onClick} aria-label="Podsumowanie"><span>Podsumowanie</span><b>{text}</b>{short?<small className="studio-quote-badge-short">{short}</small>:null}</button>;
}

function Individual({label,Heading,quote}:{label:string;Heading:"h3"|"h5";quote:QuoteState}){
 return <section className="studio-project-quote" aria-label={label}><Heading>Wycena projektu</Heading><p>Przygotujemy indywidualną wycenę po poznaniu projektu i miejsca realizacji.</p>{quote.error?<button type="button" onClick={quote.retry}>Spróbuj przeliczyć ponownie</button>:null}{contact}</section>;
}

export function ProjectQuote({quote,title,label="Cena orientacyjna projektu",headingLevel=3}:{quote:QuoteState;title?:string;label?:string;headingLevel?:3|5}){
 const Heading=headingLevel===5?'h5':'h3';
 const data=quote.data;
 if(PRICE_MODE==="construction"){
  // Amounts only with a rate card (owner rule); a standalone surface has no construction row.
  const priced=!!data?.constructionPrices,c=priced?constructionPrice(data):null,b=priced?concreteBasePrice(data):null,f=priced?surfaceFinish(data):null,pr=priced?matPrintPrice(data):null;
  if(c===null&&b===null&&f?.net==null&&!quote.loading)return <Individual label={label} Heading={Heading} quote={quote}/>;
  const split=b!==null||f!==null,total=(c??0)+(b??0)+(f?.net??0)+(pr??0);
  return <section className="studio-project-quote" aria-label={label} aria-busy={quote.loading}>
   <Heading>{title||(c===null?(f?.label.startsWith("Mata treningowa")?"Cena maty":"Cena nawierzchni"):split?"Cena konstrukcji i nawierzchni":"Cena konstrukcji")}</Heading>
   <div role="status" aria-live="polite">{quote.loading||(c===null&&!split)?<p>Przeliczam aktualną konfigurację…</p>:!split&&c!==null?<>
    <p className="studio-quote-total"><strong>{money(c)}</strong> netto</p>
    <p className="studio-quote-range-note">{data?.exclusions.some(e=>e.startsWith("Zamówienie obejmuje samą konstrukcję"))?"Zamawiasz samą konstrukcję z bramkami. Montaż i transport wyceniamy indywidualnie, po zdjęciach placu.":"Konstrukcja z bramkami w wybranym modelu. Nawierzchnię, montaż, transport i przygotowanie podłoża wyceniamy indywidualnie, po zdjęciach placu."}</p>
   </>:<>
    <dl className="studio-quote-items studio-quote-split">
     {c!==null?<div><dt>Konstrukcja boiska<small>Konstrukcja z bramkami w wybranym modelu</small></dt><dd>{money(c)} netto</dd></div>:null}
     {b!==null?<div><dt>Nawierzchnia betonowa<small>Płyta 12 cm z podbudową, bez wykończenia</small></dt><dd>{money(b)} netto</dd></div>:null}
     <div><dt>{f?f.label:"Wykończenie nawierzchni"}<small>{f?.note||"Bez wykończenia. Wykończenie wybierzesz w kroku Nawierzchnia → Materiał."}</small></dt><dd>{f?.net!=null?`${money(f.net)} netto`:<span className="studio-quote-pending">{f?"Do wyceny":"—"}</span>}</dd></div>
     {pr!==null?<div><dt>Nadruk ćwiczeń<small>{data?.items.find(i=>i.id==="mat-print")?.note}</small></dt><dd>{money(pr)} netto</dd></div>:null}
    </dl>
    <p className="studio-quote-sum">Razem: <strong>{money(total)}</strong> netto{f&&f.net===null?" + wykończenie do wyceny":""}</p>
    {b!==null?<details className="studio-quote-scope"><summary>Co obejmuje nawierzchnia betonowa</summary><ul>{CONCRETE_BASE_INCLUDES.map(t=><li key={t}>{t}</li>)}</ul><p>Nie obejmuje:</p><ul>{CONCRETE_BASE_EXCLUDES.map(t=><li key={t}>{t}</li>)}</ul></details>:null}
    {f?.net!=null?<p className="studio-quote-range-note">{f.label.startsWith("Nawierzchnia EPDM")?EPDM_NOTES[1]:f.label.startsWith("Płytki")?TILE_NOTES.join(" "):f.label.startsWith("Sztuczna trawa")?TURF_NOTES.join(" "):f.label.startsWith("Akryl Hard Court")?ACRYLIC_NOTES.join(" "):f.label.startsWith("Płyty gumowe")?RUBBER_NOTES[0]:f.label.startsWith("Maty gumowe")?MAT_NOTES[1]:PAINT_NOTES[1]}</p>:null}
    <p className="studio-quote-range-note">{c!==null?"Montaż konstrukcji i transport wyceniamy indywidualnie, po zdjęciach placu.":f?.label.startsWith("Mata treningowa")?"Mata wysyłana w całości, gotowa do rozłożenia, bez podłoża i montażu. Wysyłkę wyceniamy po podaniu adresu.":"Transport i ewentualne przygotowanie istniejącego placu wyceniamy indywidualnie, po zdjęciach."}</p>
   </>}</div>
   {contact}
   <p className="studio-quote-footnote">Cena orientacyjna netto, nie jest ofertą handlową.</p>
  </section>;
 }
 const range=priceRange(data);
 if(!range&&!quote.loading)return <Individual label={label} Heading={Heading} quote={quote}/>;
 return <section className="studio-project-quote" aria-label={label} aria-busy={quote.loading}>
  <Heading>{title||"Cena orientacyjna"}</Heading>
  <div role="status" aria-live="polite">{quote.loading||!range||!data?<p>Przeliczam aktualną konfigurację…</p>:<>
   <p className="studio-quote-total"><strong>{formatPriceRange(range)}</strong></p>
   <p className="studio-quote-range-note">{range.high===null?"Część pozycji wymaga indywidualnej wyceny i nie jest wliczona.":"Widełki dla wybranego zakresu: konstrukcja, nawierzchnia, grafika, montaż, projekt i transport."} Bez przygotowania terenu, podbudowy i fundamentów.</p>
   {range.working?<p className="studio-quote-notice">Ceny orientacyjne. Ostateczną ofertę potwierdzimy po sprawdzeniu miejsca realizacji i podłoża.</p>:null}
  </>}</div>
  {!quote.loading&&data&&range?<>
   <details className="studio-quote-scope"><summary>Z czego składa się cena ({data.items.length})</summary><dl className="studio-quote-items">{data.items.map(item=><div key={item.id}><dt>{item.label}<small>{qty(item.quantity)} {item.unit}</small>{item.note?<small>{item.note}</small>:null}</dt><dd>{item.totalNet===null?<span className="studio-quote-pending">Do wyceny</span>:money(item.totalNet)}</dd></div>)}</dl></details>
   <details className="studio-quote-scope"><summary>Zakres i założenia</summary><ul>{[...data.assumptions,...data.exclusions].map((text,i)=><li key={i}>{text}</li>)}</ul></details>
  </>:null}
  {contact}
  <p className="studio-quote-footnote">Kwoty netto. Cena orientacyjna nie jest ofertą handlową.</p>
 </section>;
}
